import boto3
import base64
import os
import urllib.parse

s3 = boto3.client('s3')

def lambda_handler(event, context):
	if 'httpMethod' in event and event['httpMethod'] == 'OPTIONS':
		# Handle OPTIONS (CORS preflight request)
		return {
			'statusCode': 200,
			'headers': {
				'Access-Control-Allow-Origin': '*',
				'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
				'Access-Control-Allow-Headers': 'Content-Type',
			},
			'body': json.dumps({'message': 'CORS preflight request successful'})
		}

	s3_bucket_name = os.getenv('S3_BUCKET_NAME')
	path_to_current_image = urllib.parse.unquote(os.getenv('PATH_TO_CURRENT_IMAGE'))

	try:
		body = event.get("body")
		if body and isinstance(body, str):
			import json
			body = json.loads(body)

		if not body or not body.get("image_data"):
			return {
				"statusCode": 400,
				"body": {"message": "No image data provided"},
				'headers': {
					'Access-Control-Allow-Origin' : '*',
					'Access-Control-Allow-Methods' : 'OPTIONS,POST,GET',
					'Access-Control-Allow-Headers' : 'Content-Type',
				}
			}

		image_data = body["image_data"]  # base64-encoded string

		image_bytes = base64.b64decode(image_data)

		s3.put_object(
			Bucket=s3_bucket_name,
			Key=path_to_current_image,
			Body=image_bytes,
			ContentType="image/png"
		)

		return {
			"statusCode": 200,
			"body": {"message": f"Successfully replaced {path_to_current_image}"}	,
			'headers': {
					'Access-Control-Allow-Origin' : '*',
					'Access-Control-Allow-Methods' : 'OPTIONS,POST,GET',
					'Access-Control-Allow-Headers' : 'Content-Type',
			}
		}

	except Exception as e:
		return {
			"statusCode": 500,
			"body": {"message": f"Failed to update image: {str(e)}"},
			'headers': {
					'Access-Control-Allow-Origin' : '*',
					'Access-Control-Allow-Methods' : 'OPTIONS,POST,GET',
					'Access-Control-Allow-Headers' : 'Content-Type',
			}
		}