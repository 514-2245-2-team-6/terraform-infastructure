import boto3
import base64
import os

s3 = boto3.client('s3')

BUCKET_NAME = 'projectawscrowdimages3bucket'
CURRENT_IMAGE= "crowd-images/current_image"

def lambda_handler(event, context):
    try:
        body = event.get("body")
        if body and isinstance(body, str):
            import json
            body = json.loads(body)

        image_data = body["image_data"]  # base64-encoded string

        image_bytes = base64.b64decode(image_data)

        s3.put_object(
            Bucket=BUCKET_NAME,
            Key=CURRENT_IMAGE,
            Body=image_bytes,
            ContentType="image/png"
        )

        return {
            "statusCode": 200,
            "body": f"Successfully replaced {CURRENT_IMAGE}"
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": f"Failed to update image: {str(e)}"
        }