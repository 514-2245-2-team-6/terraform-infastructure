import json

def lambda_handler(event, context):
    if event['httpMethod'] == 'OPTIONS':
        # Handle OPTIONS (CORS preflight request)
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
                'Access-Control-Allow-Headers': 'Content-Type',
            },
            'body': json.dumps({'message': 'CORS preflight request successful'})
        }

    body = json.loads(event.get("body", "{}"))

    mouse_left = body.get("left") # Normalized x coordinate of mouse click
    mouse_top = body.get("top") # Normalized y coordinate of mouse click
    bounding_box = body.get("bounding_box") # Bounding box of the face to click

    if not mouse_left or not mouse_top or not bounding_box:
        return {
            'statusCode': 400,
            'body': json.dumps('Missing x, y, or bounding_box'),
						'headers' : {
								'Access-Control-Allow-Origin' : '*',
								'Access-Control-Allow-Methods' : 'OPTIONS,POST,GET',
								'Access-Control-Allow-Headers' : 'Content-Type',
						}
        }

    width = bounding_box.get("Width")
    height = bounding_box.get("Height")
    left = bounding_box.get("Left")
    top = bounding_box.get("Top")

    if not width or not height or not left or not top:
        return {
            'statusCode': 400,
            'body': json.dumps('Missing width, height, left, or top in bounding_box'),
						'headers' : {
								'Access-Control-Allow-Origin' : '*',
								'Access-Control-Allow-Methods' : 'OPTIONS,POST,GET',
								'Access-Control-Allow-Headers' : 'Content-Type',
						}
        }

    if (
        mouse_left < left or
        mouse_left > left + width or
        mouse_top < top or
        mouse_top > top + height
    ):
        return {
            'statusCode': 200,
            'body': json.dumps({
                'isCorrect': False,
                'message': 'Click not within bounding box'
            }),
						'headers' : {
								'Access-Control-Allow-Origin' : '*',
								'Access-Control-Allow-Methods' : 'OPTIONS,POST,GET',
								'Access-Control-Allow-Headers' : 'Content-Type',
						}
        }
    else:
        return {
            'statusCode': 200,
            'body': json.dumps({
                'isCorrect': True,
                'message': 'Click within bounding box'
            }),
						'headers' : {
								'Access-Control-Allow-Origin' : '*',
								'Access-Control-Allow-Methods' : 'OPTIONS,POST,GET',
								'Access-Control-Allow-Headers' : 'Content-Type',
						}
        }
