import boto3
import os
import random
import json

s3 = boto3.client('s3')
sns = boto3.client('sns')

S3_BUCKET_NAME = 'projectawscrowdimages3bucket'
PATH_TO_CROWD_IMAGES = "crowd-images"
PATH_TO_CURRENT_IMAGE = 'current-image.png'

def get_path_to_random_image(s3_bucket_name, images_folder_prefix):
		s3 = boto3.client("s3")

		# List objects in the specified folder
		response = s3.list_objects_v2(
				Bucket=s3_bucket_name,
				Prefix=images_folder_prefix
		)

		if "Contents" not in response:  # Check if folder is empty
				print("No contents found in the specified folder.")
				return None

		# Filter out directories (keys ending in "/") and non-image files
		image_files = [
				obj["Key"] for
						obj in response["Contents"]
						if obj["Key"].lower().endswith(("jpg", "jpeg", "png", "gif", "webp"))
		]

		if not image_files:
				print("No image files found in the specified folder.")
				return None  # No images found

		# Select a random image
		path_to_random_image = random.choice(image_files)

		return path_to_random_image


def copy_object_to_path(s3_bucket_name, path_to_copied_object, path_to_copied_location):
		# Copy the object to the specified location
		s3.copy_object(
				Bucket=s3_bucket_name,
				CopySource={
						'Bucket': s3_bucket_name,
						'Key': path_to_copied_object
				},
				Key=path_to_copied_location
		)

def lambda_handler(event, context):
		print("Received event: " + json.dumps(event, indent=2))

		sns_topic_arn = os.getenv('SNS_TOPIC_ARN')

		path_to_random_image = get_path_to_random_image(S3_BUCKET_NAME, PATH_TO_CROWD_IMAGES)

		if not path_to_random_image:
				return {
						'statusCode': 400,
						'body': 'No images found in crowd-images folder'
				}

		copy_source = {
				'Bucket': S3_BUCKET_NAME,
				'Key': path_to_random_image
		}

		s3.copy_object(
				CopySource=copy_source,
				Bucket=S3_BUCKET_NAME,
				Key=PATH_TO_CURRENT_IMAGE,
				ContentType='image/png',
				MetadataDirective='REPLACE'
		)

		response = sns.publish(
				TopicArn=sns_topic_arn,
				Subject="Where's Waldo Update",
				Message="Hey! The Where's Waldo game image has been updated, come check it out!"
		)

		print("Message sent! ID:", response['MessageId'])
		print(f"Updated {PATH_TO_CURRENT_IMAGE} with {path_to_random_image}")

		return {
				'statusCode': 200,
				'body': f"{PATH_TO_CURRENT_IMAGE} updated with {path_to_random_image}",
		}
