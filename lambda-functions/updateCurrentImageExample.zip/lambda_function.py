import json
import boto3
import random

s3 = boto3.client('s3')

S3_BUCKET_NAME = 'projectawscrowdimages3bucket'
PATH_TO_CROWD_IMAGES = "crowd-images"
PATH_TO_CURRENT_IMAGE = 'current-image.png'

def get_path_to_random_image(s3_bucket_name, images_folder_prefix):
    s3 = boto3.client("s3")

    # List objects in the specified folder
    response = s3.list_objects_v2(
        Bucket=s3_bucket_name,
        Prefix=images_folder_prefix
    )

    if "Contents" not in response:  # Check if folder is empty
        print("No contents found in the specified folder.")
        return None

    # Filter out directories (keys ending in "/") and non-image files
    image_files = [
        obj["Key"] for
            obj in response["Contents"]
            if obj["Key"].lower().endswith(("jpg", "jpeg", "png", "gif", "webp"))
    ]

    if not image_files:
        print("No image files found in the specified folder.")
        return None  # No images found

    # Select a random image
    path_to_random_image = random.choice(image_files)

    return path_to_random_image


def copy_object_to_path(s3_bucket_name, path_to_copied_object, path_to_copied_location):
    # Copy the object to the specified location
    s3.copy_object(
        Bucket=s3_bucket_name,
        CopySource={
            'Bucket': s3_bucket_name,
            'Key': path_to_copied_object
        },
        Key=path_to_copied_location
    )


def lambda_handler(event, context):
    print("Received event: " + json.dumps(event, indent=2))

    # Get the object from the event and show its content type
    s3_bucket_name = S3_BUCKET_NAME
    path_to_crowd_images = PATH_TO_CROWD_IMAGES
    path_to_current_image = PATH_TO_CURRENT_IMAGE

    try:
        path_to_random_image = get_path_to_random_image(s3_bucket_name, path_to_crowd_images)
        if path_to_random_image:
            print("Random image path:", path_to_random_image)
            copy_object_to_path(s3_bucket_name, path_to_random_image, path_to_current_image)
            print("Image copied successfully.")

            url_to_current_image = s3.generate_presigned_url(
                'get_object',
                Params={
                    'Bucket': s3_bucket_name,
                    'Key': path_to_current_image
                }
            )

            return {
                'statusCode': 200,
                'body': {
                    'message': f'Image {path_to_random_image} copied successfully to {path_to_current_image}.',
                    'current_image_url': url_to_current_image
                }
            }
        else:
            print("No image found.")
            return {
                'statusCode': 404,
                'body': json.dumps('No image found.')
            }
    except Exception as e:
        print(e)
        print('Error getting object {} from bucket {}. Make sure they exist and your bucket is in the same region as this function.'.format(path_to_current_image, s3_bucket_name))
        raise e
